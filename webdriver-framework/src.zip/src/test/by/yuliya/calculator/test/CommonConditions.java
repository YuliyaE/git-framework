package by.yuliya.calculator.test;

import by.yuliya.calculator.driver.DriverSingleton;
import by.yuliya.calculator.util.TestListener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;

@Listeners(TestListener.class)
public class CommonConditions {

    protected WebDriver driver;

    @BeforeTest
    public void setUp(){
        DriverSingleton.getDriver();
        /*driver = new OperaDriver();
        driver.manage().window().maximize();*/
    }

    @AfterTest
    public void tearDown(){
        DriverSingleton.closeDriver();
       // driver.quit();
    }
}
